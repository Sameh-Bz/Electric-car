## fairauction

Sample smart contract

    Allows an auctioneer to auction a number of tokens.
    The contract owner takes a small fee.
    The contract guarantees that the tokens will be sent to the highest bidder,
    and that the losing bidders will be completely refunded. 
    Everyone involved stakes their tokens, so there is no possibility for anyone
    to cheat.
