## corecontracts

Tests core contract interfaces
