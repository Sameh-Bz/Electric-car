// Copyright 2020 IOTA Stiftung
// SPDX-License-Identifier: Apache-2.0

const DUMMY: u32 = 60;
