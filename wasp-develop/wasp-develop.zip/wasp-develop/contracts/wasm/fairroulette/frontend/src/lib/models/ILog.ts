export type ILog = {
  tag: string;
  timestamp: string;
  description: string;
};
