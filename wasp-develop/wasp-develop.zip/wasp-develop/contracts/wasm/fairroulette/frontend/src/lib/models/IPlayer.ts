export type IPlayer = {
  address: string;
  bet: number;
  number?: number;
};
