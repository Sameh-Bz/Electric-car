## fairroulette

Sample smart contract

    A simple betting contract. Betters can bet on a random color and after
    a predefined time period the contract will automatically pay the total
    bet amount proportionally to the bet size of the winners. 
