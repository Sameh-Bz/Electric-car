## dividend

Simple dividend smart contract
