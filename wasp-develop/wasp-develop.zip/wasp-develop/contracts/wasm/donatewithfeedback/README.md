## donatewithfeedback

Sample smart contract

    Allows for donations and registers feedback associated with the donation.
    The contract owner can at any point decide to withdraw donated funds
    from the contract.
